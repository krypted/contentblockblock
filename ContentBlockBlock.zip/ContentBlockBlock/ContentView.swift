//
//  ContentView.swift
//  Shared
//
//  Created by Charles Edge on 3/31/21.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Content Blocker")
            .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
