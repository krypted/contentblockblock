//
//  ContentBlockBlockApp.swift
//  Shared
//
//  Created by Charles Edge on 3/31/21.
//

import SwiftUI

@main
struct ContentBlockBlockApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
